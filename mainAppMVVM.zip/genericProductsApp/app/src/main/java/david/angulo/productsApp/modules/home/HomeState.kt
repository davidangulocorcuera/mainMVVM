package david.angulo.productsApp.modules.home

sealed class HomeState{

}