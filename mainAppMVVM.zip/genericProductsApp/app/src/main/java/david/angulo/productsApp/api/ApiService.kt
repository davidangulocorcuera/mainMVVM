package david.angulo.productsApp.api



interface ApiService {
}