package david.angulo.productsApp.modules.utils

object ConstantsPlatform {
    val LOCATION_REQUEST_CODE = 1
    val GOOGLE_AUTH_REQUEST_CODE = 2
    val REGISTER_REQUEST_TAG = "registerRequest"
}