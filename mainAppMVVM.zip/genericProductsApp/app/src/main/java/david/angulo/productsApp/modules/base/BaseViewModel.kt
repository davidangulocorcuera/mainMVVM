package david.angulo.productsApp.modules.base

import android.app.Application
import androidx.lifecycle.AndroidViewModel

open class BaseViewModel(app: Application) : AndroidViewModel(app)
